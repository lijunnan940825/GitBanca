create table Advice  (
   transNo              VARCHAR2(35)                    not null,
   adviceDate        VARCHAR2(300),
   postalCode              VARCHAR2(300),
   cityNative                VARCHAR2(300),
   cityNative2                  VARCHAR2(300),
   addr1          VARCHAR2(300),
   addr2          VARCHAR2(300),
   custName            VARCHAR2(300),
   custName2              VARCHAR2(300),
   productName       VARCHAR2(300),
   productName2        VARCHAR2(300),
   companName         VARCHAR2(300),
   companName2          VARCHAR2(300),
   applicationOrPolicy             VARCHAR2(300),
   applicationOrPolicy2            VARCHAR2(300),
   contNoOrPrtNo                VARCHAR2(300),
   insuredDate                   VARCHAR2(300),
   premiumNature              VARCHAR2(300),
   premiumNature2           VARCHAR2(300),
   premiumCcy               VARCHAR2(300),
   premiumAmt                  VARCHAR2(300),
   premiumDeductionDate              VARCHAR2(300),
   accountNo             VARCHAR2(300),
   transRefNo                 VARCHAR2(300),
   remarks               VARCHAR2(300),
   branchName         VARCHAR2(300),
   branchName2             VARCHAR2(300),
   constraint PK_Advice primary key (TransNo)
);
alter table LCCont add(BASECONT VARCHAR2(500));
alter table LCCont add(PRINTFLAG VARCHAR2(10));
commit;